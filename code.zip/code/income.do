/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Baseline
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/cex_panel_final.dta", clear

drop if missing(income_quintile)

foreach var in cons_total cons_nondurable cons_services cons_durable {
    quietly sum `var', detail
    local p1  = r(p1)
    local p99 = r(p99)
    replace `var' = `p1'  if `var' < `p1'  & !missing(`var')
    replace `var' = `p99' if `var' > `p99' & !missing(`var')
}

preserve
    collapse                                                          ///
        (mean) cons_total     cons_nondurable                        ///
               cons_services  cons_durable                           ///
               [aw = FINLWT21]                                       ///
        , by(cal_quarter income_quintile)

    reshape wide cons_total cons_nondurable cons_services cons_durable, ///
        i(cal_quarter) j(income_quintile)

    foreach v in cons_total cons_nondurable cons_services cons_durable {
        rename `v'1 `v'_Q1
        rename `v'2 `v'_Q2
		rename `v'3 `v'_Q3
        rename `v'4 `v'_Q4
		rename `v'5 `v'_Q5
    }

    save "$out/final_income.dta", replace
restore


use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_income.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp*100
gen rhousep = housep/pgdp*100
	

foreach var in cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 ///
               cons_nondurable_Q1 cons_nondurable_Q2 cons_nondurable_Q3 cons_nondurable_Q4 cons_nondurable_Q5 ///
			   cons_services_Q1 cons_services_Q2 cons_services_Q3 cons_services_Q4 cons_services_Q5 ///
			   cons_durable_Q1 cons_durable_Q2 cons_durable_Q3 cons_durable_Q4 cons_durable_Q5 {
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 ///
               cons_nondurable_Q1 cons_nondurable_Q2 cons_nondurable_Q3 cons_nondurable_Q4 cons_nondurable_Q5 ///
			   cons_services_Q1 cons_services_Q2 cons_services_Q3 cons_services_Q4 cons_services_Q5 ///
			   cons_durable_Q1 cons_durable_Q2 cons_durable_Q3 cons_durable_Q4 cons_durable_Q5{
  
  gen l`var' = ln(`var') 
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	

gen tfp = dtfp_util

gen h = t - 1	

global shock tfp

local p = 4 	

forvalues i = 0/20 {

foreach var in lcons_total_Q1  lcons_total_Q2 lcons_total_Q3  lcons_total_Q4 lcons_total_Q5 ///
               lcons_nondurable_Q1 lcons_nondurable_Q2 lcons_nondurable_Q3 lcons_nondurable_Q4 lcons_nondurable_Q5 ///
			   lcons_services_Q1 lcons_services_Q2 lcons_services_Q3 lcons_services_Q4 lcons_services_Q5 ///
			   lcons_durable_Q1 lcons_durable_Q2 lcons_durable_Q3 lcons_durable_Q4 lcons_durable_Q5{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp
scalar sd_tfp = r(sd)

forvalues q = 1/5 {
    foreach var in lcons_total_Q`q' lcons_nondurable_Q`q' ///
                   lcons_services_Q`q' lcons_durable_Q`q'   {

        forvalues i = 0/20 {
            quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
            quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
        }

        quietly replace up90`var' = .
        quietly replace lo90`var' = .
        forvalues i = 0/20 {
            quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
            quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
        }
        quietly replace b`var' = b`var' * 100 * sd_tfp
    }
}

local c1  "175 169 236"
local c2  "127 119 221"
local c3  "83 74 183"
local c4  "60 52 137"
local c5  "38 33 92"

local b1  "175 169 236%40"
local b2  "127 119 221%40"
local b3  "83 74 183%40"
local b4  "60 52 137%40"
local b5  "38 33 92%40"


forvalues q = 1/5 {
    foreach cat in total nondurable services durable {

        local var lcons_`cat'_Q`q'

        capture drop sm_b`var' sm_up`var' sm_lo`var'

        quietly lpoly b`var'    h if h<=20, generate(sm_b`var')  ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)

        quietly lpoly up90`var' h if h<=20, generate(sm_up`var') ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)

        quietly lpoly lo90`var' h if h<=20, generate(sm_lo`var') ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }
}

twoway ///
    (line sm_blcons_total_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_total_Q2 h if h<=20,                                                         ///
       lcolor("127 119 221") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_total_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_total_Q4 h if h<=20,                                                         ///
       lcolor("60 52 13") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_total_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
	, title("Income Levels", size(medsmall) color(black))                   ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    legend(order(1 "Q1" 2 "Q2" 3 "Q3" 4 "Q4" 5 "Q5") ///
            pos(5) ring(0) cols(1) size(*0.7) symxsize(*0.6) symysize(*0.6) colgap(*0.5) rowgap(*0.5))            ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total, replace)                                ///
    saving(income_lcons_total.gph, replace)

local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))

* Panel 2 — Nondurables
twoway ///
    (line sm_blcons_nondurable_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_nondurable_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_total_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    , ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))      ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
	ytitle("Income Levels",size(small) margin(right))                   ///
    text(-0.4 20 "Q1", size(tiny) color("175 169 236"))   ///
	text(0.4 20 "Q3", size(tiny) color("83 74 183"))   ///
    text(0.1 20 "Q5", size(tiny) color("38 33 92"))   ///
    yline(0, lcolor(black) lwidth(thin))                             ///
    legend(off)                                      ///
    graphregion(color(white)) plotregion(color(white))  ///                                                         ///
    saving(income_lcons_nondurable.gph, replace)


* Panel 3 — Services
twoway ///
    (line sm_blcons_services_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_services_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_services_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    , `gopts'                                                           ///
    saving(income_lcons_services.gph, replace)


* Panel 4 — Durables
twoway ///
    (line sm_blcons_durable_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_durable_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_durable_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
       , `gopts'                                                           ///
    saving(income_lcons_durable.gph, replace)





	
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Lag Selection
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_income.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
	
	
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100
	

foreach var in cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 {
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5{
  
  gen l`var' = ln(`var') 
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	

gen tfp = dtfp_util

gen h = t - 1	
	

global shock tfp
local p = 6 

forvalues i = 0/20 {

foreach var in lcons_total_Q1  lcons_total_Q2 lcons_total_Q3  lcons_total_Q4 lcons_total_Q5 {

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp
scalar sd_tfp = r(sd)

forvalues q = 1/5 {
    foreach var in lcons_total_Q`q'  {

        forvalues i = 0/20 {
            quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
            quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
        }

        quietly replace up90`var' = .
        quietly replace lo90`var' = .
        forvalues i = 0/20 {
            quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
            quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
        }
        quietly replace b`var' = b`var' * 100 * sd_tfp
    }
}

local c1  "175 169 236"
local c2  "127 119 221"
local c3  "83 74 183"
local c4  "60 52 137"
local c5  "38 33 92"

local b1  "175 169 236%40"
local b2  "127 119 221%40"
local b3  "83 74 183%40"
local b4  "60 52 137%40"
local b5  "38 33 92%40"


forvalues q = 1/5 {
    foreach cat in total {

        local var lcons_`cat'_Q`q'

        capture drop sm_b`var' sm_up`var' sm_lo`var'

        quietly lpoly b`var'    h if h<=20, generate(sm_b`var')  ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)

        quietly lpoly up90`var' h if h<=20, generate(sm_up`var') ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)

        quietly lpoly lo90`var' h if h<=20, generate(sm_lo`var') ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }
}

twoway ///
    (line sm_blcons_total_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_total_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_total_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    , title("Consumption(Income Levels)", size(medsmall) color(black))                ///
	xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    legend(off)            ///
	text(0.3 20 "Q1", size(tiny) color("175 169 236"))   ///
    text(0.05 20 "Q3", size(tiny) color("83 74 183"))     ///
 	text(-0.6 20 "Q5", size(tiny) color("38 33 92"))   ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_lag, replace)                                ///
    saving(income_lcons_total_lag.gph, replace)


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Cholesky 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_income.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100
	

foreach var in cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 {
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 {
  
  gen l`var' = ln(`var')

}

gen tfp = dtfp_util
gen h = t - 1	


quietly summarize tfp
scalar sd_tfp = r(sd)
global sd_tfp_val = sd_tfp

local p = 4
local horizon = 20

local cats  "tot"
local cfull "total"
local grps  "Q1 Q2 Q3 Q4 Q5"


forvalues ci = 1/1 {
    local cat  : word `ci' of tot 
    local cf   : word `ci' of total 

    forvalues gi = 1/5 {
        local grp  : word `gi' of Q1 Q2 Q3 Q4 Q5

        di as text "  VAR: `cf' — `grp'  (irf: chol_`cat'_`grp')"

        quietly var tfp lrgdp lrstockp lrhousep lxtot lcons_`cf'_`grp', ///
            lags(1/`p') exog(t t2)

        quietly irf create chol_`cat'_`grp', ///
            step(`horizon') set(irf_income_chol) replace
    }
}

use irf_income_chol.irf, clear

keep if impulse == "tfp"

gen upper = oirf + 1.68 * stdoirf
gen lower = oirf - 1.68 * stdoirf

foreach var of varlist oirf upper lower {
    replace `var' = `var' * 100 * $sd_tfp_val
}

rename step h

save "irf_income_chol_data.dta", replace

local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Quarters after shock", size(small) margin(top))           ///
    ytitle("% deviation from steady state", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))
	
twoway ///
    (line oirf h                                                          ///
        if irfname == "chol_tot_Q1"                                ///
        & response == "lcons_total_Q1" & h<=20,                      ///
        lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line oirf h                                                          ///
        if irfname == "chol_tot_Q3"                                  ///
        & response == "lcons_total_Q3" & h<=20,                        ///
        lcolor("83 74 183") lwidth(medthick) lpattern(solid))     ///
	(line oirf h                                                          ///
        if irfname == "chol_tot_Q5"                                  ///
        & response == "lcons_total_Q5" & h<=20,                        ///
        lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
	, title("Consumption(Income Levels)", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
 	legend(off)       ///                                                   ///
	text(-2.5 20 "Q1", size(tiny) color("175 169 236"))   ///
	text(0.3 20 "Q3", size(tiny) color("83 74 183"))   ///
	text(1.2 20 "Q5", size(tiny) color("38 33 92"))   ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_cholesky, replace)                                ///
    saving(income_lcons_total_cholesky.gph, replace)





/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Residual 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_income.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100
	

foreach var in cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5 {
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_Q1  cons_total_Q2 cons_total_Q3  cons_total_Q4 cons_total_Q5{
  
  gen l`var' = ln(`var') 
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	

gen tfp = dtfp_util	

newey tfp L(1/4).tfp L(1/4).lrgdp L(1/4).lrstockp L(1/4).lrhousep L(1/4).lxtot t t2,lag(4)
predict tfp_purged, resid

gen h = t - 1

global shock tfp_purged

local p = 4 


forvalues i = 0/20 {

foreach var in lcons_total_Q1  lcons_total_Q2 lcons_total_Q3  lcons_total_Q4 lcons_total_Q5 {

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp_purged
scalar sd_tfp = r(sd)

forvalues q = 1/5 {
    foreach var in lcons_total_Q`q'  {

        forvalues i = 0/20 {
            quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
            quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
        }

        quietly replace up90`var' = .
        quietly replace lo90`var' = .
        forvalues i = 0/20 {
            quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
            quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
        }
        quietly replace b`var' = b`var' * 100 * sd_tfp
    }
}

local c1  "175 169 236"
local c2  "127 119 221"
local c3  "83 74 183"
local c4  "60 52 137"
local c5  "38 33 92"

local b1  "175 169 236%40"
local b2  "127 119 221%40"
local b3  "83 74 183%40"
local b4  "60 52 137%40"
local b5  "38 33 92%40"


forvalues q = 1/5 {
    foreach cat in total {

        local var lcons_`cat'_Q`q'

        capture drop sm_b`var' sm_up`var' sm_lo`var'

        quietly lpoly b`var'    h if h<=20, generate(sm_b`var')  ///
            at(h) nograph degree(3) bwidth(3) kernel(epanechnikov)

        quietly lpoly up90`var' h if h<=20, generate(sm_up`var') ///
            at(h) nograph degree(3) bwidth(3) kernel(epanechnikov)

        quietly lpoly lo90`var' h if h<=20, generate(sm_lo`var') ///
            at(h) nograph degree(3) bwidth(3) kernel(epanechnikov)
    }
}

twoway ///
    (line sm_blcons_total_Q1 h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_blcons_total_Q3 h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_blcons_total_Q5 h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    , title("Consumption(Income Levels)", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters) ", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    legend(off)       ///                                                   ///
	text(0.6 20 "Q1", size(tiny) color("175 169 236"))   ///
	text(1.4 20 "Q3", size(tiny) color("83 74 183"))   ///
	text(0.04 20 "Q5", size(tiny) color("38 33 92"))   ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_residual, replace)                                ///
    saving(income_lcons_total_residual.gph, replace)
	
