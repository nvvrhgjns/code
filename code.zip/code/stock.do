/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Baseline
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/cex_panel_final.dta", clear

replace stock_holder = 0 if missing(stock_holder)

foreach var in cons_total cons_nondurable cons_services cons_durable {
    quietly sum `var', detail
    local p1  = r(p1)
    local p99 = r(p99)
    replace `var' = `p1'  if `var' < `p1'  & !missing(`var')
    replace `var' = `p99' if `var' > `p99' & !missing(`var')
}

preserve

    collapse                                                          ///
        (mean) cons_total     cons_nondurable                        ///
               cons_services  cons_durable                           ///
               [aw = FINLWT21]                                       ///
        , by(cal_quarter stock_holder)

    reshape wide cons_total cons_nondurable cons_services cons_durable, ///
        i(cal_quarter) j(stock_holder)

    foreach v in cons_total cons_nondurable cons_services cons_durable {
        rename `v'0 `v'_nostock
        rename `v'1 `v'_stock
    }

    save "$out/final_stock.dta", replace
restore


use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_stock.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
	
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp *100
gen rhousep = housep/pgdp *100

foreach var in cons_total_nostock  cons_total_stock cons_nondurable_nostock ///
               cons_nondurable_stock cons_services_nostock cons_services_stock ///
			   cons_durable_nostock cons_durable_stock{
  replace `var' = `var'/pgdp *100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_nostock  cons_total_stock cons_nondurable_nostock ///
               cons_nondurable_stock cons_services_nostock cons_services_stock ///
			   cons_durable_nostock cons_durable_stock {
  
  gen l`var' = ln(`var')
 
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	
gen tfp = dtfp_util

gen h = t - 1	

global shock tfp
local p = 4 	

forvalues i = 0/20 {

foreach var in lcons_total_nostock  lcons_total_stock lcons_nondurable_nostock ///
               lcons_nondurable_stock lcons_services_nostock lcons_services_stock ///
			   lcons_durable_nostock lcons_durable_stock{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp
scalar sd_tfp = r(sd)

foreach var in lcons_total_nostock      lcons_total_stock      ///
               lcons_nondurable_nostock lcons_nondurable_stock ///
               lcons_services_nostock   lcons_services_stock   ///
               lcons_durable_nostock    lcons_durable_stock  {

    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}

foreach var in lcons_total_nostock      lcons_total_stock      ///
               lcons_nondurable_nostock lcons_nondurable_stock ///
               lcons_services_nostock   lcons_services_stock   ///
               lcons_durable_nostock    lcons_durable_stock  {

    capture drop sm_b`var' sm_up90`var' sm_lo90`var'

    lpoly b`var'     h if h<=20, generate(sm_b`var')     at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly up90`var'  h if h<=20, generate(sm_up90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly lo90`var'  h if h<=20, generate(sm_lo90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)
}

* Panel 1 — Total consumptiom
twoway ///
    (rarea sm_up90lcons_total_nostock sm_lo90lcons_total_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nostock h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    , title("Stock Ownership", size(medsmall) color(black))                   ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))      ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                             ///
    legend(order(2 "Non-stockowner" 5 "Stockowner") ///
      pos(11) ring(0) cols(1)   size(*0.5) symxsize(*0.5) symysize(*0.5) colgap(*0.5) rowgap(*0.5))                                   ///
    graphregion(color(white)) plotregion(color(white))               ///
    name(stock_total, replace) ///
    saving(stock_lcons_total.gph, replace)
	
local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    yline(0, lcolor(black) lwidth(thin))                               ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
	legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))                 ///
   
* Panel 2 — Nondurables
twoway ///
    (rarea sm_up90lcons_nondurable_nostock sm_lo90lcons_nondurable_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_nondurable_nostock h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_nondurable_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_nondurable_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))      ///
    ytitle("Stock Ownership", size(small) margin(right))                   ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    text(1.5   20 "Non-stockowner", size(tiny) color("27 58 92"))   ///
	text(-0.5 20 "Stockowner", size(tiny) color("180 50 30"))   ///
	yline(0, lcolor(black) lwidth(thin))                             ///
    legend(off)  ///
    graphregion(color(white)) plotregion(color(white))               ///                     ///
    saving(stock_lcons_nondurable.gph, replace)


* Panel 3 — Services
twoway ///
    (rarea sm_up90lcons_services_nostock sm_lo90lcons_services_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                         ///
    (line sm_blcons_services_nostock h if h<=20,                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))           ///
    (line sm_up90lcons_services_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_services_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_services_stock h if h<=20,                            ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))           ///
    , `gopts'                                                             ///
    saving(stock_lcons_services.gph, replace)


* Panel 4 — Durables
twoway ///
    (rarea sm_up90lcons_durable_nostock sm_lo90lcons_durable_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                         ///
    (line sm_blcons_durable_nostock h if h<=20,                           ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))           ///
    (line sm_up90lcons_durable_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_durable_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_durable_stock h if h<=20,                             ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))           ///
    , `gopts'                                                             ///
    saving(stock_lcons_durable.gph, replace)

	
	
	
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Lag Selection
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_stock.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
	
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100

foreach var in cons_total_nostock  cons_total_stock {
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_nostock  cons_total_stock  {
  
  gen l`var' = ln(`var')
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	
gen tfp = dtfp_util

gen h = t - 1	

global shock tfp
local p = 6 	

forvalues i = 0/20 {

foreach var in lcons_total_nostock  lcons_total_stock{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp
scalar sd_tfp = r(sd)

foreach var in lcons_total_nostock      lcons_total_stock {

    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}

foreach var in lcons_total_nostock      lcons_total_stock  {

    capture drop sm_b`var' sm_up90`var' sm_lo90`var'

    lpoly b`var'     h if h<=20, generate(sm_b`var')     at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly up90`var'  h if h<=20, generate(sm_up90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly lo90`var'  h if h<=20, generate(sm_lo90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)
}

* Panel 1 — Total consumptiom
twoway ///
    (rarea sm_up90lcons_total_nostock sm_lo90lcons_total_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nostock h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
	, title("Consumption(Stock Ownership)", size(medsmall) color(black))                ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))      ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                             ///
    legend(off)       ///
	text(0.5 20 "Non-stockowner", size(tiny) color("27 58 92"))   ///
    text(-1 20 "Stockowner", size(tiny) color("180 50 30"))     ///
    graphregion(color(white)) plotregion(color(white))               ///
    name(stock_total_lag, replace) ///
    saving(stock_lcons_total_lag.gph, replace)

	
	
	
	
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Cholesky 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_stock.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100
	

foreach var in cons_total_nostock  cons_total_stock{
  replace `var' = `var'/pgdp * 100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_nostock  cons_total_stock {
  
  gen l`var' = ln(`var')
  
}

gen tfp = dtfp_util
gen h = t - 1	


quietly summarize tfp
scalar sd_tfp = r(sd)
global sd_tfp

local p = 4
local horizon = 20

local cats  "tot  "
local cfull "total "
local grps  "ns  st"
local gfull "nostock stock"

forvalues ci = 1/1 {
    local cat  : word `ci' of tot 
    local cf   : word `ci' of total 

    forvalues gi = 1/2 {
        local grp  : word `gi' of ns st
        local gf   : word `gi' of nostock stock

        di as text "  VAR: `cf' — `gf'  (irf: chol_`cat'_`grp')"

        quietly var tfp lrgdp lrstockp lrhousep lxtot lcons_`cf'_`gf', ///
            lags(1/`p') exog(t t2)

        quietly irf create chol_`cat'_`grp', ///
            step(`horizon') set(irf_stock_chol) replace
    }
}

use irf_stock_chol.irf, clear

keep if impulse == "tfp"

gen upper = oirf + 1.68 * stdoirf
gen lower = oirf - 1.68 * stdoirf

foreach var of varlist oirf upper lower {
    replace `var' = `var' * 100 * sd_tfp
}

rename step h

save "irf_stock_chol_data.dta", replace

twoway ///
    (rarea upper lower h                                                  ///
        if irfname == "chol_tot_ns"                                ///
        & response == "lcons_total_nostock" & h<=20,                      ///
        fcolor("27 58 92%40") lwidth(none))                            ///
    (line oirf h                                                          ///
        if irfname == "chol_tot_ns"                                ///
        & response == "lcons_total_nostock" & h<=20,                      ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))            ///
     (line upper h                                                          ///
        if irfname == "chol_tot_st"                                  ///
        & response == "lcons_total_stock" & h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
	 (line lower h                                                          ///
        if irfname == "chol_tot_st"                                  ///
        & response == "lcons_total_stock" & h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line oirf h                                                          ///
        if irfname == "chol_tot_st"                                  ///
        & response == "lcons_total_stock" & h<=20,                        ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))            ///
    , title("Consumption(Stock Ownership)", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
     legend(off)                      ///
	text(-0.6 20 "Non-stockonwer", size(tiny) color("27 58 92"))   ///
    text(1.5 20 "Stockowner", size(tiny) color("180 50 30"))     ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(stock_total_cholesky, replace)                                ///
    saving(stock_lcons_total_cholesky.gph, replace)

	
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Residual
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use	"/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_stock.dta",clear
merge 1:1 cal_quarter using ///
    "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/final_data.dta",keep(3) nogen
	
gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot  = rgdp/emp
gen rstockp = stockp_sh/pgdp *100
gen rhousep = housep/pgdp *100

foreach var in cons_total_nostock  cons_total_stock {
  replace `var' = `var'/pgdp *100
}

foreach var in rgdp xtot tothours pgdp rstockp rhousep ///
               cons_total_nostock  cons_total_stock  {
  
  gen l`var' = ln(`var')
 
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}
	
gen tfp = dtfp_util

gen h = t - 1	


newey tfp L(1/4).tfp L(1/4).lrgdp L(1/4).lrstockp L(1/4).lrhousep L(1/4).lxtot t t2,lag(4)
predict tfp_purged, resid

global shock tfp_purged
local p = 4 	

forvalues i = 0/20 {

foreach var in lcons_total_nostock  lcons_total_stock {

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp
scalar sd_tfp = r(sd)

foreach var in lcons_total_nostock      lcons_total_stock {
    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}

foreach var in lcons_total_nostock      lcons_total_stock  {

    capture drop sm_b`var' sm_up90`var' sm_lo90`var'

    lpoly b`var'     h if h<=20, generate(sm_b`var')     at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly up90`var'  h if h<=20, generate(sm_up90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)

    lpoly lo90`var'  h if h<=20, generate(sm_lo90`var')  at(h) nograph ///
        degree(3) bwidth(2) kernel(epanechnikov)
}

* Panel 1 — Total consumptiom
twoway ///
    (rarea sm_up90lcons_total_nostock sm_lo90lcons_total_nostock h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nostock h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_stock h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))      ///
    xtitle("Quarters after shock", size(small) margin(top))          ///
    ytitle("% deviation from steady state", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                             ///
    legend(off)                                                      ///
    text(-0.6 20 "Non-stockowner", size(tiny) color("27 58 92"))   ///
    text(0.4 20 "Stockowner", size(tiny) color("180 50 30"))     ///
    graphregion(color(white)) plotregion(color(white))               ///
    name(stock_total, replace) ///
    saving(stock_lcons_total_residual.gph, replace)
	
