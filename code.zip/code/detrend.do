/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Mortgage
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all 
use "$out/final_mortgage.dta", clear
merge 1:1 cal_quarter using "$out/final_data.dta", keep(3) nogen

gen qdate = q(1989q4) + _n-1
tsset qdate, q


gen t  = _n
gen t2 = t^2

gen xtot    = rgdp / emp
gen rstockp = stockp_sh / pgdp * 100
gen rhousep = housep / pgdp * 100

foreach var in cons_total_nomort cons_total_mort {
    replace `var' = `var' / pgdp * 100
}

foreach var in rgdp xtot rstockp rhousep                ///
               cons_total_nomort cons_total_mort {
    gen l`var' = ln(`var')
	gen dl`var' = D.l`var'
}


gen jf_tfp  = dtfp_util

gen h = t - 1


foreach var in lcons_total_nomort lcons_total_mort {
    tsfilter hp `var'_cyc = `var', smooth(1600)
}

foreach var in lrgdp lxtot lrstockp lrhousep {
    tsfilter hp `var'_cyc = `var', smooth(1600)
}


foreach var in lcons_total_nomort lcons_total_mort {
    foreach spec in bl fd hp lt {
        quietly gen b`var'_`spec'    = .
        quietly gen up90`var'_`spec' = .
        quietly gen lo90`var'_`spec' = .
    }
}

quietly sum jf_tfp
scalar sd_tfp = r(sd)


local p       = 4
local horizon = 20

forvalues i = 0/`horizon' {

    foreach var in lcons_total_nomort lcons_total_mort {

        * ── SPEC 1: Baseline — log levels + quadratic trend (t + t²) ─────────
        quietly newey F`i'.`var'                              ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp    L(1/`p').lrstockp              ///
            L(1/`p').lrhousep L(1/`p').lxtot                 ///
            L(1/`p').`var' t t2, lag(`=`i'+1')

        quietly gen b`var'h`i'_bl  = _b[jf_tfp]
        quietly gen se`var'h`i'_bl = _se[jf_tfp]
        quietly replace b`var'_bl    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_bl = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_bl = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 2: First differences — ∆log levels, no trend needed ─────────
        * Response: cumulated sum of ∆log IRF = level-equivalent response
        quietly newey F`i'.d`var'                            ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').dlrgdp    L(1/`p').dlrstockp            ///
            L(1/`p').dlrhousep L(1/`p').dlxtot               ///
            L(1/`p').d`var', lag(`=`i'+1')

        quietly gen b`var'h`i'_fd  = _b[jf_tfp]
        quietly gen se`var'h`i'_fd = _se[jf_tfp]
        quietly replace b`var'_fd    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_fd = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_fd = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 3: HP-filtered cyclical deviations ───────────────────────────
        quietly newey F`i'.`var'_cyc                          ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp_cyc    L(1/`p').lrstockp_cyc      ///
            L(1/`p').lrhousep_cyc L(1/`p').lxtot_cyc         ///
            L(1/`p').`var'_cyc, lag(`=`i'+1')

        quietly gen b`var'h`i'_hp  = _b[jf_tfp]
        quietly gen se`var'h`i'_hp = _se[jf_tfp]
        quietly replace b`var'_hp    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_hp = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_hp = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 4: Linear trend only (t, no t²) ─────────────────────────────
        quietly newey F`i'.`var'                              ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp    L(1/`p').lrstockp              ///
            L(1/`p').lrhousep L(1/`p').lxtot                 ///
            L(1/`p').`var' t, lag(`=`i'+1')

        quietly gen b`var'h`i'_lt  = _b[jf_tfp]
        quietly gen se`var'h`i'_lt = _se[jf_tfp]
        quietly replace b`var'_lt    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_lt = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_lt = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'
    }
}


local horizon = 20
foreach var in lcons_total_nomort lcons_total_mort {

    * ── Normalise log-level specs (bl, hp, lt) ───────────────────────────────
    foreach spec in bl hp lt {
        forvalues i = 0/`horizon' {
            quietly replace b`var'h`i'_`spec'  = b`var'h`i'_`spec'  * 100 * sd_tfp if h == `i'
            quietly replace se`var'h`i'_`spec' = se`var'h`i'_`spec' * 100 * sd_tfp if h == `i'
        }
        quietly replace b`var'_`spec' = b`var'_`spec' * 100 * sd_tfp
        quietly replace up90`var'_`spec' = .
        quietly replace lo90`var'_`spec' = .
        forvalues i = 0/`horizon' {
            quietly replace up90`var'_`spec' = b`var'h`i'_`spec' + 1.68*se`var'h`i'_`spec' if h == `i'
            quietly replace lo90`var'_`spec' = b`var'h`i'_`spec' - 1.68*se`var'h`i'_`spec' if h == `i'
        }
    }

    forvalues i = 0/`horizon' {
        quietly replace b`var'h`i'_fd  = b`var'h`i'_fd  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i'_fd = se`var'h`i'_fd * 100 * sd_tfp if h == `i'
    }
    gen cum_b`var'_fd    = .
    gen cum_up`var'_fd   = .
    gen cum_lo`var'_fd   = .

    quietly replace cum_b`var'_fd  = b`var'h0_fd if h == 0
    quietly replace cum_up`var'_fd = b`var'h0_fd + 1.68*se`var'h0_fd if h == 0
    quietly replace cum_lo`var'_fd = b`var'h0_fd - 1.68*se`var'h0_fd if h == 0

    forvalues i = 1/`horizon' {
        local im1 = `i' - 1
        quietly replace cum_b`var'_fd = cum_b`var'_fd[_n-1] + b`var'h`i'_fd   if h == `i'
        quietly replace cum_up`var'_fd = cum_b`var'_fd + 1.68*se`var'h`i'_fd  if h == `i'
        quietly replace cum_lo`var'_fd = cum_b`var'_fd - 1.68*se`var'h`i'_fd  if h == `i'
    }
}

* ── Smooth cumulated FD ────────────────────────────────────────────────
foreach var in lcons_total_nomort      lcons_total_mort  {

         capture drop sm_cum_b`var'_fd sm_cum_up`var'_fd sm_cum_lo`var'_fd

         lpoly cum_b`var'_fd     h if h<=20, generate(sm_cum_b`var'_fd)     at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)

         lpoly cum_up`var'_fd  h if h<=20, generate(sm_cum_up`var'_fd)  at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)

         lpoly cum_lo`var'_fd  h if h<=20, generate(sm_cum_lo`var'_fd)  at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)
}


* ── Smooth HP filter (hp) ─────────────────────────────────────────────
foreach var in lcons_total_nomort      lcons_total_mort  {

         capture drop sm_b`var'_hp sm_up90`var'_hp sm_lo90`var'_hp

         lpoly b`var'_hp     h if h<=20, generate(sm_b`var'_hp)     at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly up90`var'_hp  h if h<=20, generate(sm_up90`var'_hp)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly lo90`var'_hp  h if h<=20, generate(sm_lo90`var'_hp)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)
}
    
* ── Smooth linear trend (lt) ───────────────────────────────────────────────────
foreach var in lcons_total_nomort      lcons_total_mort  {

         capture drop sm_b`var'_lt sm_up90`var'_lt sm_lo90`var'_lt

         lpoly b`var'_lt     h if h<=20, generate(sm_b`var'_lt)     at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly up90`var'_lt  h if h<=20, generate(sm_up90`var'_lt)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly lo90`var'_lt  h if h<=20, generate(sm_lo90`var'_lt)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)
}


local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    graphregion(color(white)) plotregion(color(white))

twoway ///
    (rarea sm_cum_uplcons_total_nomort_fd sm_cum_lolcons_total_nomort_fd h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_cum_blcons_total_nomort_fd h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_cum_uplcons_total_mort_fd h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_cum_lolcons_total_mort_fd h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_cum_blcons_total_mort_fd h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,title("First Difference", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
	ytitle("Mortgage Status", size(small) margin(right)) ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)                      ///
	text(0.3 20 "Without mortgage", size(tiny) color("27 58 92"))   ///
    text(1.3 20 "With mortgage", size(tiny) color("180 50 30"))     ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(mortgage_total_fd, replace)                                ///
    saving(mort_lcons_total_fd.gph, replace)	
	
twoway ///
    (rarea sm_up90lcons_total_nomort_hp sm_lo90lcons_total_nomort_hp h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nomort_hp h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_mort_hp h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_mort_hp h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_mort_hp h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,title("HP filter", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)                      ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(mortgage_total_hp, replace)                                ///
    saving(mort_lcons_total_hp.gph, replace)	

twoway ///
    (rarea sm_up90lcons_total_nomort_lt sm_lo90lcons_total_nomort_lt h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nomort_lt h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_mort_lt h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_mort_lt h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_mort_lt h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,title("Linear trend", size(medsmall) color(black))            ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)                      ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(mortgage_total_lt, replace)                                ///
    saving(mort_lcons_total_lt.gph, replace)		


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Stock
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all
use "$out/final_stock.dta", clear
merge 1:1 cal_quarter using "$out/final_data.dta", keep(3) nogen

gen qdate = q(1989q4) + _n-1
tsset qdate, q


gen t  = _n
gen t2 = t^2

gen xtot    = rgdp / emp
gen rstockp = stockp_sh / pgdp * 100
gen rhousep = housep / pgdp * 100

foreach var in cons_total_nostock cons_total_stock {
    replace `var' = `var' / pgdp * 100
}

foreach var in rgdp xtot rstockp rhousep                ///
               cons_total_nostock cons_total_stock {
    gen l`var' = ln(`var')
	gen dl`var' = D.l`var'
}


gen jf_tfp  = dtfp_util

gen h = t - 1

* HP filter with lambda=1600 (standard for quarterly data)
foreach var in lcons_total_nostock lcons_total_stock {
    tsfilter hp `var'_cyc = `var', smooth(1600)
}

foreach var in lrgdp lxtot lrstockp lrhousep {
    tsfilter hp `var'_cyc = `var', smooth(1600)
}

foreach var in lcons_total_nostock lcons_total_stock {
    foreach spec in bl fd hp lt {
        quietly gen b`var'_`spec'    = .
        quietly gen up90`var'_`spec' = .
        quietly gen lo90`var'_`spec' = .
    }
}

quietly sum jf_tfp
scalar sd_tfp = r(sd)


local p       = 4
local horizon = 20

forvalues i = 0/`horizon' {

    foreach var in lcons_total_nostock lcons_total_stock {

        * ── SPEC 1: Baseline — log levels + quadratic trend (t + t²) ─────────
        quietly newey F`i'.`var'                              ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp    L(1/`p').lrstockp              ///
            L(1/`p').lrhousep L(1/`p').lxtot                 ///
            L(1/`p').`var' t t2, lag(`=`i'+1')

        quietly gen b`var'h`i'_bl  = _b[jf_tfp]
        quietly gen se`var'h`i'_bl = _se[jf_tfp]
        quietly replace b`var'_bl    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_bl = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_bl = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 2: First differences — ∆log levels, no trend needed ─────────
        * Response: cumulated sum of ∆log IRF = level-equivalent response
        quietly newey F`i'.d`var'                            ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').dlrgdp    L(1/`p').dlrstockp            ///
            L(1/`p').dlrhousep L(1/`p').dlxtot               ///
            L(1/`p').d`var', lag(`=`i'+1')

        quietly gen b`var'h`i'_fd  = _b[jf_tfp]
        quietly gen se`var'h`i'_fd = _se[jf_tfp]
        quietly replace b`var'_fd    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_fd = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_fd = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 3: HP-filtered cyclical deviations ───────────────────────────
        quietly newey F`i'.`var'_cyc                          ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp_cyc    L(1/`p').lrstockp_cyc      ///
            L(1/`p').lrhousep_cyc L(1/`p').lxtot_cyc         ///
            L(1/`p').`var'_cyc, lag(`=`i'+1')

        quietly gen b`var'h`i'_hp  = _b[jf_tfp]
        quietly gen se`var'h`i'_hp = _se[jf_tfp]
        quietly replace b`var'_hp    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_hp = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_hp = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 4: Linear trend only (t, no t²) ─────────────────────────────
        quietly newey F`i'.`var'                              ///
            L(0/`p').jf_tfp                                  ///
            L(1/`p').lrgdp    L(1/`p').lrstockp              ///
            L(1/`p').lrhousep L(1/`p').lxtot                 ///
            L(1/`p').`var' t, lag(`=`i'+1')

        quietly gen b`var'h`i'_lt  = _b[jf_tfp]
        quietly gen se`var'h`i'_lt = _se[jf_tfp]
        quietly replace b`var'_lt    = _b[jf_tfp]                   if h == `i'
        quietly replace up90`var'_lt = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90`var'_lt = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'
    }
}



foreach var in lcons_total_nostock lcons_total_stock {

    * ── Normalise log-level specs (bl, hp, lt) ───────────────────────────────
    foreach spec in bl hp lt {
        forvalues i = 0/`horizon' {
            quietly replace b`var'h`i'_`spec'  = b`var'h`i'_`spec'  * 100 * sd_tfp if h == `i'
            quietly replace se`var'h`i'_`spec' = se`var'h`i'_`spec' * 100 * sd_tfp if h == `i'
        }
        quietly replace b`var'_`spec' = b`var'_`spec' * 100 * sd_tfp
        quietly replace up90`var'_`spec' = .
        quietly replace lo90`var'_`spec' = .
        forvalues i = 0/`horizon' {
            quietly replace up90`var'_`spec' = b`var'h`i'_`spec' + 1.68*se`var'h`i'_`spec' if h == `i'
            quietly replace lo90`var'_`spec' = b`var'h`i'_`spec' - 1.68*se`var'h`i'_`spec' if h == `i'
        }
    }


    forvalues i = 0/`horizon' {
        quietly replace b`var'h`i'_fd  = b`var'h`i'_fd  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i'_fd = se`var'h`i'_fd * 100 * sd_tfp if h == `i'
    }

    gen cum_b`var'_fd    = .
    gen cum_up`var'_fd   = .
    gen cum_lo`var'_fd   = .

    quietly replace cum_b`var'_fd  = b`var'h0_fd if h == 0
    quietly replace cum_up`var'_fd = b`var'h0_fd + 1.68*se`var'h0_fd if h == 0
    quietly replace cum_lo`var'_fd = b`var'h0_fd - 1.68*se`var'h0_fd if h == 0

    forvalues i = 1/`horizon' {
        local im1 = `i' - 1
        quietly replace cum_b`var'_fd = cum_b`var'_fd[_n-1] + b`var'h`i'_fd   if h == `i'
        * CI for cumulated IRF uses Newey-West sum — approximate with 1.68*SE
        quietly replace cum_up`var'_fd = cum_b`var'_fd + 1.68*se`var'h`i'_fd  if h == `i'
        quietly replace cum_lo`var'_fd = cum_b`var'_fd - 1.68*se`var'h`i'_fd  if h == `i'
    }
}


* ── Smooth cumulated FD ────────────────────────────────────────────────
foreach var in lcons_total_nostock      lcons_total_stock  {

         capture drop sm_cum_b`var'_fd sm_cum_up`var'_fd sm_cum_lo`var'_fd

         lpoly cum_b`var'_fd     h if h<=20, generate(sm_cum_b`var'_fd)     at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)

         lpoly cum_up`var'_fd  h if h<=20, generate(sm_cum_up`var'_fd)  at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)

         lpoly cum_lo`var'_fd  h if h<=20, generate(sm_cum_lo`var'_fd)  at(h) nograph ///
             degree(3) bwidth(3) kernel(epanechnikov)
}


* ── Smooth HP filter (hp) ─────────────────────────────────────────────
foreach var in lcons_total_nostock      lcons_total_stock  {

         capture drop sm_b`var'_hp sm_up90`var'_hp sm_lo90`var'_hp

         lpoly b`var'_hp     h if h<=20, generate(sm_b`var'_hp)     at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly up90`var'_hp  h if h<=20, generate(sm_up90`var'_hp)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly lo90`var'_hp  h if h<=20, generate(sm_lo90`var'_hp)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)
}
   
* ── Smooth linear trend (lt) ───────────────────────────────────────────────────
foreach var in lcons_total_nostock      lcons_total_stock  {

         capture drop sm_b`var'_lt sm_up90`var'_lt sm_lo90`var'_lt

         lpoly b`var'_lt     h if h<=20, generate(sm_b`var'_lt)     at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly up90`var'_lt  h if h<=20, generate(sm_up90`var'_lt)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)

         lpoly lo90`var'_lt  h if h<=20, generate(sm_lo90`var'_lt)  at(h) nograph ///
             degree(3) bwidth(4) kernel(epanechnikov)
}


local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    graphregion(color(white)) plotregion(color(white))

twoway ///
    (rarea sm_cum_uplcons_total_nostock_fd sm_cum_lolcons_total_nostock_fd h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_cum_blcons_total_nostock_fd h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_cum_uplcons_total_stock_fd h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_cum_lolcons_total_stock_fd h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_cum_blcons_total_stock_fd h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
	ytitle("Stock Ownership", size(small) margin(right)) ///
    legend(off)                      ///
	text(0.5 20 "Non-stockowner", size(tiny) color("27 58 92"))   ///
    text(1.3 20 "Stockowner", size(tiny) color("180 50 30"))     ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(stock_total_fd, replace)                                ///
    saving(stock_lcons_total_fd.gph, replace)	
	
twoway ///
    (rarea sm_up90lcons_total_nostock_hp sm_lo90lcons_total_nostock_hp h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nostock_hp h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_stock_hp h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_stock_hp h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock_hp h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)                      ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(stock_total_hp, replace)                                ///
    saving(stock_lcons_total_hp.gph, replace)	

twoway ///
    (rarea sm_up90lcons_total_nostock_lt sm_lo90lcons_total_nostock_lt h if h<=20, ///
        fcolor("27 58 92%50") lwidth(none))                        ///
    (line sm_blcons_total_nostock_lt h if h<=20,                            ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))        ///
    (line sm_up90lcons_total_stock_lt h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_lo90lcons_total_stock_lt h  if h<=20,                        ///
        lcolor("180 50 30%40") lwidth(medthick) lpattern(dash))            ///
    (line sm_blcons_total_stock_lt h if h<=20,                              ///
        lcolor("180 50 30") lwidth(medthick) lpattern(solid))        ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)                      ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(stock_total_lt, replace)                                ///
    saving(stock_lcons_total_lt.gph, replace)		



/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Income 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all 
use "$out/final_income.dta", clear
merge 1:1 cal_quarter using "$out/final_data.dta", keep(3) nogen

gen qdate = q(1989q4) + _n-1
tsset qdate, q


gen t  = _n
gen t2 = t^2

gen xtot    = rgdp / emp
gen rstockp = stockp_sh / pgdp * 100
gen rhousep = housep / pgdp * 100

forvalues q = 1/5 {
    foreach cat in total nondurable services durable {
        replace cons_`cat'_Q`q' = cons_`cat'_Q`q' / pgdp * 100
    }
}

foreach var in rgdp xtot rstockp rhousep {
    gen l`var' = ln(`var')
}
forvalues q = 1/5 {
    gen lcons_total_Q`q' = ln(cons_total_Q`q')
}

foreach var in rgdp xtot rstockp rhousep {
    gen dl`var' = D.l`var'
}
forvalues q = 1/5 {
    gen dlcons_total_Q`q' = D.lcons_total_Q`q'
}

foreach var in lrgdp lxtot lrstockp lrhousep {
    tsfilter hp `var'_cyc = `var', smooth(1600)
}
forvalues q = 1/5 {
    tsfilter hp lcons_total_Q`q'_cyc = lcons_total_Q`q', smooth(1600)
}

gen jf_tfp = dtfp_util

quietly summarize jf_tfp
scalar sd_tfp = r(sd)
global sd_tfp_val = sd_tfp
di "SD of TFP shock = $sd_tfp_val"

gen h = t - 1

forvalues q = 1/5 {
    foreach spec in bl fd hp lt {
        quietly gen b_Q`q'_`spec'    = .
        quietly gen up90_Q`q'_`spec' = .
        quietly gen lo90_Q`q'_`spec' = .
    }
    quietly gen cum_b_Q`q'_fd    = .
    quietly gen cum_up_Q`q'_fd   = .
    quietly gen cum_lo_Q`q'_fd   = .
}

local p       = 4
local horizon = 20

forvalues i = 0/`horizon' {

    forvalues q = 1/5 {

        * ── SPEC 1 (bl): Log levels + quadratic trend ────────────────────────
        quietly newey F`i'.lcons_total_Q`q'                          ///
            L(0/`p').jf_tfp                                          ///
            L(1/`p').lrgdp    L(1/`p').lrstockp                      ///
            L(1/`p').lrhousep L(1/`p').lxtot                         ///
            L(1/`p').lcons_total_Q`q' t t2, lag(`=`i'+1')

        quietly gen b_Q`q'h`i'_bl  = _b[jf_tfp]
        quietly gen se_Q`q'h`i'_bl = _se[jf_tfp]
        quietly replace b_Q`q'_bl    = _b[jf_tfp]                   if h == `i'
        quietly replace up90_Q`q'_bl = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90_Q`q'_bl = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 2 (fd): First differences ───────────────────────────────────
        quietly newey F`i'.dlcons_total_Q`q'                         ///
            L(0/`p').jf_tfp                                          ///
            L(1/`p').dlrgdp    L(1/`p').dlrstockp                    ///
            L(1/`p').dlrhousep L(1/`p').dlxtot                       ///
            L(1/`p').dlcons_total_Q`q', lag(`=`i'+1')

        quietly gen b_Q`q'h`i'_fd  = _b[jf_tfp]
        quietly gen se_Q`q'h`i'_fd = _se[jf_tfp]
        quietly replace b_Q`q'_fd    = _b[jf_tfp]                   if h == `i'
        quietly replace up90_Q`q'_fd = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90_Q`q'_fd = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 3 (hp): HP-filtered cyclical deviations ─────────────────────
        quietly newey F`i'.lcons_total_Q`q'_cyc                      ///
            L(0/`p').jf_tfp                                          ///
            L(1/`p').lrgdp_cyc    L(1/`p').lrstockp_cyc              ///
            L(1/`p').lrhousep_cyc L(1/`p').lxtot_cyc                 ///
            L(1/`p').lcons_total_Q`q'_cyc, lag(`=`i'+1')

        quietly gen b_Q`q'h`i'_hp  = _b[jf_tfp]
        quietly gen se_Q`q'h`i'_hp = _se[jf_tfp]
        quietly replace b_Q`q'_hp    = _b[jf_tfp]                   if h == `i'
        quietly replace up90_Q`q'_hp = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90_Q`q'_hp = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'

        * ── SPEC 4 (lt): Log levels + linear trend only ──────────────────────
        quietly newey F`i'.lcons_total_Q`q'                          ///
            L(0/`p').jf_tfp                                          ///
            L(1/`p').lrgdp    L(1/`p').lrstockp                      ///
            L(1/`p').lrhousep L(1/`p').lxtot                         ///
            L(1/`p').lcons_total_Q`q' t, lag(`=`i'+1')

        quietly gen b_Q`q'h`i'_lt  = _b[jf_tfp]
        quietly gen se_Q`q'h`i'_lt = _se[jf_tfp]
        quietly replace b_Q`q'_lt    = _b[jf_tfp]                   if h == `i'
        quietly replace up90_Q`q'_lt = _b[jf_tfp]+1.68*_se[jf_tfp] if h == `i'
        quietly replace lo90_Q`q'_lt = _b[jf_tfp]-1.68*_se[jf_tfp] if h == `i'
    }
}

forvalues q = 1/5 {

    * ── Specs bl, hp, lt: direct normalisation ───────────────────────────────
    foreach spec in bl hp lt {
        forvalues i = 0/`horizon' {
            quietly replace b_Q`q'h`i'_`spec'  = b_Q`q'h`i'_`spec'  * 100 * $sd_tfp_val if h == `i'
            quietly replace se_Q`q'h`i'_`spec' = se_Q`q'h`i'_`spec' * 100 * $sd_tfp_val if h == `i'
        }
        quietly replace b_Q`q'_`spec' = b_Q`q'_`spec' * 100 * $sd_tfp_val
        quietly replace up90_Q`q'_`spec' = .
        quietly replace lo90_Q`q'_`spec' = .
        forvalues i = 0/`horizon' {
            quietly replace up90_Q`q'_`spec' = b_Q`q'h`i'_`spec' + 1.68*se_Q`q'h`i'_`spec' if h == `i'
            quietly replace lo90_Q`q'_`spec' = b_Q`q'h`i'_`spec' - 1.68*se_Q`q'h`i'_`spec' if h == `i'
        }
    }

    * ── Spec fd: normalise then cumulate to level-equivalent IRF ─────────────
    forvalues i = 0/`horizon' {
        quietly replace b_Q`q'h`i'_fd  = b_Q`q'h`i'_fd  * 100 * $sd_tfp_val if h == `i'
        quietly replace se_Q`q'h`i'_fd = se_Q`q'h`i'_fd * 100 * $sd_tfp_val if h == `i'
    }

    * Cumulate: level IRF at h = Σ(k=0 to h) β^k_fd
    quietly replace cum_b_Q`q'_fd  = b_Q`q'h0_fd  if h == 0
    quietly replace cum_up_Q`q'_fd = b_Q`q'h0_fd + 1.68*se_Q`q'h0_fd if h == 0
    quietly replace cum_lo_Q`q'_fd = b_Q`q'h0_fd - 1.68*se_Q`q'h0_fd if h == 0

    forvalues i = 1/`horizon' {
        quietly replace cum_b_Q`q'_fd  = cum_b_Q`q'_fd[_n-1]  + b_Q`q'h`i'_fd           if h == `i'
        quietly replace cum_up_Q`q'_fd = cum_b_Q`q'_fd         + 1.68*se_Q`q'h`i'_fd    if h == `i'
        quietly replace cum_lo_Q`q'_fd = cum_b_Q`q'_fd         - 1.68*se_Q`q'h`i'_fd    if h == `i'
    }
}

forvalues q = 1/5 {

    * ── Smooth baseline (bl) ─────────────────────────────────────────────────
    foreach obj in b up90 lo90 {
        capture drop sm_`obj'_Q`q'_bl
        lpoly `obj'_Q`q'_bl h if h<=20, generate(sm_`obj'_Q`q'_bl) ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }

    * ── Smooth HP filter (hp) ────────────────────────────────────────────────
    foreach obj in b up90 lo90 {
        capture drop sm_`obj'_Q`q'_hp
        lpoly `obj'_Q`q'_hp h if h<=20, generate(sm_`obj'_Q`q'_hp) ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }

    * ── Smooth linear trend (lt) ─────────────────────────────────────────────
    foreach obj in b up90 lo90 {
        capture drop sm_`obj'_Q`q'_lt
        lpoly `obj'_Q`q'_lt h if h<=20, generate(sm_`obj'_Q`q'_lt) ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }

    * ── Smooth cumulated FD ───────────────────────────────────────────────────
    * Note: smooth the cumulated series, not the raw FD coefficients
    foreach obj in cum_b cum_up cum_lo {
        capture drop sm_`obj'_Q`q'_fd
        lpoly `obj'_Q`q'_fd h if h<=20, generate(sm_`obj'_Q`q'_fd) ///
            at(h) nograph degree(3) bwidth(4) kernel(epanechnikov)
    }
}

twoway ///
    (line sm_cum_b_Q1_fd h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_cum_b_Q3_fd h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_cum_b_Q5_fd h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("Income Levels", size(small) margin(right)) ///
    legend(off)            ///
    text(-0.5 20 "Q1", size(tiny) color("175 169 236"))   ///
	text(1 20 "Q3", size(tiny) color("83 74 183"))   ///
	text(1.2 20 "Q5", size(tiny) color("38 33 92"))   ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_fd, replace)                                ///
    saving(income_lcons_total_fd.gph, replace)

twoway ///
    (line sm_b_Q1_hp h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_b_Q3_hp h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_b_Q5_hp h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
	ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)            ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_hp, replace)                                ///
    saving(income_lcons_total_hp.gph, replace)

twoway ///
    (line sm_b_Q1_lt h if h<=20,                                                         ///
       lcolor("175 169 236") lwidth(medthick) lpattern(solid))            ///
	(line sm_b_Q3_lt h if h<=20,                                                         ///
       lcolor("83 74 183") lwidth(medthick) lpattern(solid))   ///
	(line sm_b_Q5_lt h if h<=20,                                                            ///
       lcolor("38 33 92") lwidth(medthick) lpattern(solid))            ///
    ,xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash))    ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))          ///
    yline(0, lcolor(black) lwidth(thin))                                 ///
	ytitle("") ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    legend(off)            ///
    graphregion(color(white)) plotregion(color(white))                   ///
    name(income_total_lt, replace)                                ///
    saving(income_lcons_total_lt.gph, replace)

