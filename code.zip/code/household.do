********************************************************************************
* Mortgage Status
********************************************************************************
clear all
use "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/cex_panel_final.dta", clear

merge m:1 cal_quarter using "$out/final_data.dta", keepusing(pgdp) keep(3) nogen

drop if mortgage_holder != 0 & mortgage_holder != 1
gen year = year(dofq(cal_quarter))

foreach var in cons_total cons_nondurable cons_services cons_durable FINCBTXM {
    capture replace `var' = `var' / pgdp * 100
}

replace FSALARYX = FSALARYM if year ==2004 | year ==2005
foreach var in cons_total cons_nondurable cons_services cons_durable ///
               FSALARYX {
    capture replace `var' = `var' / pgdp * 100
}

capture scalar drop liquid_wealth
capture drop liquid_wealth
gen liquid_wealth = .
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year <  2013
replace liquid_wealth = LIQUIDX / pgdp * 100                if year >= 2013 & !missing(LIQUIDX)
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year >= 2013 &  missing(LIQUIDX)
replace liquid_wealth = 0 if liquid_wealth < 0 & !missing(liquid_wealth)

quietly count
scalar N_total = r(N)
tab mortgage_holder

tabstat AGE_REF FSALARYX  cons_total liquid_wealth ///
    , by(mortgage_holder) ///
    stats(mean  n) ///
    col(stats) ///
    format(%12.0f) ///
    varwidth(20)


********************************************************************************
* Stock Ownership
********************************************************************************
clear all
use "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/cex_panel_final.dta", clear

merge m:1 cal_quarter using "$out/final_data.dta", keepusing(pgdp) keep(3) nogen

replace stock_holder = 0 if missing(stock_holder)
gen year = year(dofq(cal_quarter))

foreach var in cons_total cons_nondurable cons_services cons_durable FINCBTXM {
    capture replace `var' = `var' / pgdp * 100
}

replace FSALARYX = FSALARYM if year ==2004 | year ==2005
foreach var in cons_total cons_nondurable cons_services cons_durable ///
               FSALARYX {
    capture replace `var' = `var' / pgdp * 100
}

capture scalar drop liquid_wealth
capture drop liquid_wealth
gen liquid_wealth = .
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year <  2013
replace liquid_wealth = LIQUIDX / pgdp * 100                if year >= 2013 & !missing(LIQUIDX)
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year >= 2013 &  missing(LIQUIDX)
replace liquid_wealth = 0 if liquid_wealth < 0 & !missing(liquid_wealth)

quietly count
scalar N_total = r(N)
tab stock_holder

tabstat AGE_REF FSALARYX  cons_total liquid_wealth ///
    , by(stock_holder) ///
    stats(mean  n) ///
    col(stats) ///
    format(%12.0f) ///
    varwidth(20)

	
	
********************************************************************************
* Income Quintile
********************************************************************************
clear all
use "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean/cex_panel_final.dta", clear

merge m:1 cal_quarter using "$out/final_data.dta", keepusing(pgdp) keep(3) nogen

drop if missing(INC_RANK)
gen year = year(dofq(cal_quarter))

foreach var in cons_total cons_nondurable cons_services cons_durable FINCBTXM {
    capture replace `var' = `var' / pgdp * 100
}

replace FSALARYX = FSALARYM if year ==2004 | year ==2005
foreach var in cons_total cons_nondurable cons_services cons_durable ///
               FSALARYX {
    capture replace `var' = `var' / pgdp * 100
}

capture scalar drop liquid_wealth
capture drop liquid_wealth
gen liquid_wealth = .
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year <  2013
replace liquid_wealth = LIQUIDX / pgdp * 100                if year >= 2013 & !missing(LIQUIDX)
replace liquid_wealth = (CKBKACTX + SAVACCTX) / pgdp * 100 if year >= 2013 &  missing(LIQUIDX)
replace liquid_wealth = 0 if liquid_wealth < 0 & !missing(liquid_wealth)

quietly count
scalar N_total = r(N)
tab income_quintile

tabstat AGE_REF FSALARYX  cons_total liquid_wealth ///
    , by(income_quintile) ///
    stats(mean  n) ///
    col(stats) ///
    format(%12.0f) ///
    varwidth(20)
