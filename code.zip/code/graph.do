/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 1 macro activity
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                          ///
    agg_lrgdp.gph         agg_lrstockp.gph    agg_lrhousep.gph      agg_lrcons.gph ///
    , cols(2)                                                          ///
	name(Figure_1, replace)                                       ///
    graphregion(color(white)) iscale(0.85)
	
graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_1.pdf",name(Figure_1) replace

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 2 household groups
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                                    ///
    mort_lcons_total.gph stock_lcons_total.gph income_lcons_total.gph ///
    , cols(2)                                                                    ///
    xsize(20) ysize(16)                                                          ///
	name(Figure_2, replace) ///
    graphregion(color(white)) iscale(0.65)                                      
	
graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_2.pdf",name(Figure_2) replace

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 3 lag selection
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                                    ///
    agg_lrgdp_lag.gph agg_lrstockp_lag.gph agg_lrhousep_lag.gph agg_lrcons_lag.gph ///
	mort_lcons_total_lag.gph   stock_lcons_total_lag.gph  income_lcons_total_lag.gph ///
	, cols(2)                                                                    ///
    xsize(16) ysize(20)                                                          ///
	name(Figure_3, replace) ///
    graphregion(color(white)) iscale(0.65)                                      
	
graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_3.pdf",name(Figure_3) replace

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 4 Cholesky 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                         ///
    chol_lrgdp.gph    chol_lrstockp.gph    chol_lrhousep.gph chol_lrcons.gph                                ///
	mort_lcons_total_cholesky.gph stock_lcons_total_cholesky.gph  income_lcons_total_cholesky.gph   ///
    , cols(2)                                                          ///
	xsize(14) ysize(20)                                               ///
	name(Figure_4, replace)                                       ///
    graphregion(color(white)) iscale(0.85)

graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure 4.pdf",name(Figure_4) replace

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 5 residual
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                          ///
    agg_lrgdp_residual.gph         agg_lrstockp_residual.gph     agg_lrhousep_residual.gph      agg_lrcons_residual.gph   ///                           ///
	mort_lcons_total_residual.gph stock_lcons_total_residual.gph income_lcons_total_residual.gph ///
    , cols(2)                                                          ///
    xsize(14) ysize(20)                                               ///
	name(Figure_5, replace)                                       ///
    graphregion(color(white)) iscale(0.85)

graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_5.pdf",name(Figure_5) replace

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 6 detrending
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine mort_lcons_total_fd.gph mort_lcons_total_hp.gph mort_lcons_total_lt.gph   ///
              stock_lcons_total_fd.gph stock_lcons_total_hp.gph stock_lcons_total_lt.gph ///
			  income_lcons_total_fd.gph income_lcons_total_hp.gph income_lcons_total_lt.gph ///
    , cols(3)                                                          ///
	xsize(20) ysize(16)                                                          ///
	name(Figure_6,replace) ///
	graphregion(color(white)) iscale(0.85)  

graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_6.pdf",name(Figure_6) replace


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Figure 7 consumption categories
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
graph combine                                                                    ///
    agg_lrcons_nondurable.gph agg_lrcons_services.gph      agg_lrcons_durable.gph ///
    mort_lcons_nondurable.gph  mort_lcons_services.gph   mort_lcons_durable.gph              ///
    stock_lcons_nondurable.gph  stock_lcons_services.gph  stock_lcons_durable.gph              ///
    income_lcons_nondurable.gph   income_lcons_services.gph    income_lcons_durable.gph                ///
    , cols(3)                                                                    ///
    xsize(20) ysize(20)                                                          ///
	name(Figure_7, replace) ///
    graphregion(color(white)) iscale(0.65)                                      
graph export "/Users/sunying/Desktop/Masterarbeit/thesis/graph/Figure_7.pdf",name(Figure_7) replace



