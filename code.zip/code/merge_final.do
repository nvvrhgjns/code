clear 

global raw  "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/raw"
global out  "/Users/sunying/Desktop/Masterarbeit/thesis/data/heterogeneity/clean"

capture program drop uppercase_vars
program define uppercase_vars
    quietly describe, varlist
    local allvars `r(varlist)'
    foreach v of local allvars {
        local V = upper("`v'")
        if "`v'" != "`V'" {
            capture rename `v' `V'
        }
    }
end


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
 FMLI 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/

local fmli_final "$out/fmli_final_tmp.dta"
local fmli_first 1

forvalues yr = 1990/2025 {

    forvalues q = 1/4 {

        local yy    = mod(`yr', 100)
        local yystr = string(`yy', "%02.0f")
        local fname "$raw/fmli`yystr'`q'.dta"

        capture confirm file "`fname'"
        if _rc != 0 {
            di as text "  [SKIP] `fname'"
            continue
        }

        di as text "  Loading `fname'  [`yr' Q`q']"

        quietly use "`fname'", clear

        uppercase_vars

        * ── NEWID ────────────────────────────────────────────────────────────
        capture confirm string variable NEWID
        if _rc != 0 {
            quietly tostring NEWID, replace format("%8.0f")
        }

        * ── CUTENURE ─────────────────────────────────────────────────────────────────
        capture confirm variable CUTENURE
        if _rc == 0 {
              capture confirm string variable CUTENURE
              if _rc == 0 {
                   quietly destring CUTENURE, replace force
              }
        }

        * ── Income Quintile ───────────────────────────
        if `yr' == 2004 | `yr' == 2005 {
            capture confirm variable FINCBTXM
            if _rc == 0 {
                quietly destring FINCBTXM, replace force
            }
            else {
                quietly gen double FINCBTXM = .
            }
            capture drop INC_RANK
            quietly gen double INC_RANK = .
        }
        else {
            capture confirm variable INC_RANK
            if _rc == 0 {
                quietly destring INC_RANK, replace force
            }
            else {
                quietly gen double INC_RANK = .
            }
            capture drop FINCBTXM
            quietly gen double FINCBTXM = .
        }

        * ── Income Level ──────────────────────────────────────────────────────────
        capture confirm variable FSALARYX
            if _rc == 0 {
                quietly destring FSALARYX, replace force
            }
            else {
                quietly gen double FSALARYX = .
            }
		
		capture confirm variable FSALARYM
            if _rc == 0 {
                quietly destring FSALARYM, replace force
            }
            else {
                quietly gen double FSALARYM = .
            }
		
        * ── FINLWT21 ─────────────────────────────────────────────────────────
        capture confirm numeric variable FINLWT21
        if _rc != 0 {
            quietly destring FINLWT21, replace force
        }

        * ── QINTRVMO ─────────────────────────────────────────────────────────
        capture confirm numeric variable QINTRVMO
        if _rc != 0 {
            quietly destring QINTRVMO, replace force
        }

        * ── QINTRVYR ─────────────────────────────────────────────────────────
        capture confirm numeric variable QINTRVYR
        if _rc != 0 {
              quietly destring QINTRVYR, replace force
        }
        quietly summarize QINTRVYR
        if `r(max)' < 100 {
             quietly replace QINTRVYR = QINTRVYR + 1900 if QINTRVYR >= 80
             quietly replace QINTRVYR = QINTRVYR + 2000 if QINTRVYR <  80
        }
		
        quietly gen int  intvw_qtr   = ceil(QINTRVMO / 3)        
		quietly gen int  cal_quarter = yq(QINTRVYR, intvw_qtr)
        quietly format   cal_quarter %tq
        quietly drop     intvw_qtr

        quietly gen int  src_year = `yr'
        quietly gen byte src_qtr  = `q'
		
		* ── AGE_REF — early years used AGER ──────────────────────────────────
        capture confirm numeric variable AGE_REF
        if _rc != 0 {
            quietly destring AGE_REF, replace force
        }

        * ── LIQUIDX ──────────────────────────────────────────────────────────
        capture confirm numeric variable LIQUIDX
        if _rc == 0 {
            quietly destring LIQUIDX, replace force
        }
        else {
            quietly gen LIQUIDX = .
        }
		
		capture confirm numeric variable CKBKACTX
        if _rc == 0 {
            quietly destring CKBKACTX, replace force
        }
        else {
            quietly gen CKBKACTX = .
        }
		
		capture confirm numeric variable SAVACCTX
        if _rc == 0 {
            quietly destring SAVACCTX, replace force
        }
        else {
            quietly gen SAVACCTX = .
        }

        * ── STOCKX ───────────────────────────────────────────────────────────
        capture confirm numeric variable STOCKX
        if _rc == 0 {
            quietly destring STOCKX, replace force
        }
        else {
            quietly gen STOCKX = .
        }

        capture confirm numeric variable SECESTX
        if _rc == 0 {
            quietly destring SECESTX, replace force
        }
        else {
            quietly gen SECESTX = .
        }

        quietly keep NEWID CUTENURE FINCBTXM INC_RANK FINLWT21 AGE_REF  ///
                     LIQUIDX FSALARYX  FSALARYM CKBKACTX SAVACCTX    ///
                     STOCKX SECESTX cal_quarter src_year src_qtr

        quietly drop if NEWID == "" | NEWID == "."
        quietly drop if cal_quarter == .

        * ── Append ────────────────────────────────────────────────────────────
        if `fmli_first' {
            save "`fmli_final'", replace
            local fmli_first 0
        }
        else {
            append using "`fmli_final'"
            save "`fmli_final'", replace
        }

    } 
} 

use "`fmli_final'", clear

quietly bysort NEWID cal_quarter: keep if _n == 1

save "$out/fmli_final.dta", replace


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
  MTBI 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
local mtbi_final "$out/mtbi_final_tmp.dta"
local mtbi_first 1

forvalues yr = 1990/2025 {
    forvalues q = 1/4 {

        local yy    = mod(`yr', 100)
        local yystr = string(`yy', "%02.0f")
        local fname "$raw/mtbi`yystr'`q'.dta"

        capture confirm file "`fname'"
        if _rc != 0 {
            di as text "  [SKIP] `fname'"
            continue
        }

        di as text "  Loading `fname'  [`yr' Q`q']"

        quietly use "`fname'", clear

        uppercase_vars

        * ── NEWID ────────────────────────────────────────────────────────────
        capture confirm string variable NEWID
        if _rc != 0 {
            quietly tostring NEWID, replace format("%8.0f")
        }

        * ── UCC ──────────────────────────────────────────────────────────────
        capture confirm string variable UCC
        if _rc != 0 {
            quietly tostring UCC, replace format("%06.0f")
        }
        quietly replace UCC = string(real(UCC), "%06.0f") ///
            if length(UCC) < 6 & real(UCC) < .

        * ── COST ─────────────────────────────────────────────────────────────
        capture confirm numeric variable COST
        if _rc != 0 {
            quietly destring COST, replace force
        }

        * ── GIFT ──────────────────────────────────────────
        capture confirm numeric variable GIFT
        if _rc != 0 {
            quietly destring GIFT, replace force
        }

        * ── REF_MO ───────────────────────────────────────────────────────────
        capture confirm numeric variable REF_MO
        if _rc != 0 {
            quietly destring REF_MO, replace force
        }
        
        * ── REF_YR ───────────────────────────────────────────────────────────
        capture confirm numeric variable REF_YR
        if _rc != 0 {
            quietly destring REF_YR, replace force
        }
		quietly summarize REF_YR
        if `r(max)' < 100 {
             quietly replace REF_YR = REF_YR + 1900 if REF_YR >= 80
             quietly replace REF_YR = REF_YR + 2000 if REF_YR <  80
        }

        quietly gen int  intvw_qtr   = ceil(REF_MO / 3)        
		quietly gen int  cal_quarter = yq(REF_YR, intvw_qtr)
        quietly format   cal_quarter %tq
        quietly drop     intvw_qtr

 
        * ── PUBFLAG ────────────────────────────────────────────────────
        capture confirm variable PUBFLAG
        if _rc == 0 {
            quietly destring PUBFLAG, replace force
        }

        quietly drop if COST == . | COST <= 0
        quietly drop if GIFT == 1
        quietly drop if UCC  == "" | UCC == "."
        quietly drop if PUBFLAG  == 1 | UCC == "."

        quietly keep NEWID UCC COST cal_quarter REF_MO REF_YR


        * ── Append ────────────────────────────────────────────────────────────
        if `mtbi_first' {
            save "`mtbi_final'", replace
            local mtbi_first 0
        }
        else {
            append using "`mtbi_final'"
            save "`mtbi_final'", replace
        }

    } 
} 

use "`mtbi_final'", clear

gen byte cat = 0

* ── NON-DURABLES ─────────────────────────────────────────────────────────────
replace cat=1 if cat==0 & inlist(UCC,"190901","190902","190903","190904","190905")
replace cat=1 if cat==0 & inlist(UCC,"790220","790230","790410","790420","790430")
replace cat=1 if cat==0 & inlist(UCC,"200900","790310","790320")
replace cat=1 if cat==0 & inlist(UCC,"250111","250112","250113","250114")
replace cat=1 if cat==0 & inlist(UCC,"250211","250212","250213","250214")
replace cat=1 if cat==0 & inlist(UCC,"250221","250222","250223")
replace cat=1 if cat==0 & inlist(UCC,"250901","250902","250903","250904")
replace cat=1 if cat==0 & inlist(UCC,"250911","250912","250913","250914")
replace cat=1 if cat==0 & inlist(UCC,"360110","360120","360210","360311","360312")
replace cat=1 if cat==0 & inlist(UCC,"360320","360330","360340","360350","360410")
replace cat=1 if cat==0 & inlist(UCC,"360420","360511","360512","360513","360901","360902")
replace cat=1 if cat==0 & inlist(UCC,"370110","370120","370125","370130")
replace cat=1 if cat==0 & inlist(UCC,"370211","370212","370213","370220")
replace cat=1 if cat==0 & inlist(UCC,"370311","370312","370313","370314")
replace cat=1 if cat==0 & inlist(UCC,"370901","370902","370903","370904")
replace cat=1 if cat==0 & inlist(UCC,"380110","380210","380311","380312","380313")
replace cat=1 if cat==0 & inlist(UCC,"380315","380320","380331","380332","380333")
replace cat=1 if cat==0 & inlist(UCC,"380340","380410","380420","380430","380510")
replace cat=1 if cat==0 & inlist(UCC,"380901","380902","380903")
replace cat=1 if cat==0 & inlist(UCC,"390110","390120","390210","390221","390222")
replace cat=1 if cat==0 & inlist(UCC,"390223","390230","390310","390321","390322")
replace cat=1 if cat==0 & inlist(UCC,"390901","390902")
replace cat=1 if cat==0 & inlist(UCC,"400110","400210","400220","400310")
replace cat=1 if cat==0 & inlist(UCC,"410110","410111","410112","410120","410121")
replace cat=1 if cat==0 & inlist(UCC,"410122","410130","410131","410132","410140")
replace cat=1 if cat==0 & inlist(UCC,"410141","410142","410901","410902","410903","410904")
replace cat=1 if cat==0 & inlist(UCC,"420110","420115","420120")
replace cat=1 if cat==0 & inlist(UCC,"630110","630210","640130","640430")
replace cat=1 if cat==0 & UCC=="540000"
replace cat=1 if cat==0 & inlist(UCC,"470111","470112","470113","470211","470212")
replace cat=1 if cat==0 & inlist(UCC,"470220","470311")
replace cat=1 if cat==0 & inlist(UCC,"590110","590111","590112","590210","590211")
replace cat=1 if cat==0 & inlist(UCC,"590212","590220","590230")

* ── SERVICES ─────────────────────────────────────────────────────────────────
replace cat=2 if cat==0 & inlist(UCC,"260111","260112","260113","260114")
replace cat=2 if cat==0 & inlist(UCC,"260211","260212","260213","260214")
replace cat=2 if cat==0 & inlist(UCC,"270211","270212","270213","270214")
replace cat=2 if cat==0 & inlist(UCC,"270411","270412","270413","270414")
replace cat=2 if cat==0 & inlist(UCC,"270901","270902","270903","270904")
replace cat=2 if cat==0 & inlist(UCC,"210110","210210","210310","210901","210902")
replace cat=2 if cat==0 & inlist(UCC,"220111","220112","220121","220122","350110")
replace cat=2 if cat==0 & inlist(UCC,"220311","220312","220313","220314","220321")
replace cat=2 if cat==0 & inlist(UCC,"220901","220902")
replace cat=2 if cat==0 & inlist(UCC,"270000","270101","270102","270103","270104")
replace cat=2 if cat==0 & inlist(UCC,"270105","270106","270310","270311")
replace cat=2 if cat==0 & inlist(UCC,"340210","340211","340212","340310","340410")
replace cat=2 if cat==0 & inlist(UCC,"340420","340510","340520","340530","340610")
replace cat=2 if cat==0 & inlist(UCC,"340620","340630","340901","340902","340903")
replace cat=2 if cat==0 & inlist(UCC,"340904","340905","340906","340907","340908")
replace cat=2 if cat==0 & inlist(UCC,"340910","340911","340912","340914","340915")
replace cat=2 if cat==0 & inlist(UCC,"440110","440120","440130","440140","440150")
replace cat=2 if cat==0 & inlist(UCC,"440210","440900")
replace cat=2 if cat==0 & inlist(UCC,"450310","450311","450350","450351","450410","450411")
replace cat=2 if cat==0 & inlist(UCC,"480100","480110","480211","480212","480213")
replace cat=2 if cat==0 & inlist(UCC,"480214","480215","480216")
replace cat=2 if cat==0 & inlist(UCC,"490110","490211","490212","490220","490221")
replace cat=2 if cat==0 & inlist(UCC,"490231","490232","490300","490311","490312")
replace cat=2 if cat==0 & inlist(UCC,"490313","490314","490315","490317","490318")
replace cat=2 if cat==0 & inlist(UCC,"490319","490411","490412","490413","490500")
replace cat=2 if cat==0 & inlist(UCC,"490501","490502","490900")
replace cat=2 if cat==0 & UCC=="500110"
replace cat=2 if cat==0 & inlist(UCC,"510110","510115","510901","510902")
replace cat=2 if cat==0 & inlist(UCC,"520110","520310","520410","520511","520512")
replace cat=2 if cat==0 & inlist(UCC,"520516","520517","520521","520522","520530")
replace cat=2 if cat==0 & inlist(UCC,"520531","520532","520541","520542","520550","520560")
replace cat=2 if cat==0 & inlist(UCC,"520901","520902","520903","520904","520905","520907")
replace cat=2 if cat==0 & inlist(UCC,"530110","530210","530311","530312")
replace cat=2 if cat==0 & inlist(UCC,"530411","530412","530510","530901","530902")
replace cat=2 if cat==0 & inlist(UCC,"550110","550320","550330","550340")
replace cat=2 if cat==0 & inlist(UCC,"560110","560210","560310","560320","560330")
replace cat=2 if cat==0 & inlist(UCC,"560400","560410","560420","560900")
replace cat=2 if cat==0 & inlist(UCC,"570110","570111","570210","570220","570230","570240")
replace cat=2 if cat==0 & inlist(UCC,"570901","570903")
replace cat=2 if cat==0 & inlist(UCC,"580111","580112","580113","580114","580115","580116")
replace cat=2 if cat==0 & inlist(UCC,"580210","580310","580311","580312")
replace cat=2 if cat==0 & inlist(UCC,"580400","580401","580402","580411","580412")
replace cat=2 if cat==0 & inlist(UCC,"580421","580422","580431","580432","580441","580442")
replace cat=2 if cat==0 & inlist(UCC,"580901","580902","580903","580904","580905","580906")
replace cat=2 if cat==0 & inlist(UCC,"580907","580908","580909","580910")
replace cat=2 if cat==0 & inlist(UCC,"650110","650210","650310","650900")
replace cat=2 if cat==0 & inlist(UCC,"660001","660110","660210","660310","660410")
replace cat=2 if cat==0 & inlist(UCC,"660900","660901","660902")
replace cat=2 if cat==0 & inlist(UCC,"670110","670210","670310","670320","670410")
replace cat=2 if cat==0 & inlist(UCC,"670901","670902","670903","671000")
replace cat=2 if cat==0 & inlist(UCC,"620110","620111","620112","620113","620114","620115")
replace cat=2 if cat==0 & inlist(UCC,"620121","620122","620211","620212","620213","620214")
replace cat=2 if cat==0 & inlist(UCC,"620215","620216","620221","620222","620310","620320")
replace cat=2 if cat==0 & inlist(UCC,"620330","620410","620420","620902","620903","620904")
replace cat=2 if cat==0 & inlist(UCC,"620905","620906","620907","620908","620909","620912")
replace cat=2 if cat==0 & inlist(UCC,"620916","620917","620918","620919","620921","620922")
replace cat=2 if cat==0 & inlist(UCC,"620926","620930","690114","690116")
replace cat=2 if cat==0 & UCC=="002120"
replace cat=2 if cat==0 & inlist(UCC,"680110","680140","680210","680220","680310","680320")
replace cat=2 if cat==0 & inlist(UCC,"680901","680902","680904","680905","710110","700110")

* ── DURABLES ─────────────────────────────────────────────────────────────────
replace cat=3 if cat==0 & inlist(UCC,"450110","450210","450220")
replace cat=3 if cat==0 & inlist(UCC,"460110","460901","460902")
replace cat=3 if cat==0 & inlist(UCC,"290110","290120","290210","290310","290320")
replace cat=3 if cat==0 & inlist(UCC,"290410","290420","290430","290440","320901")
replace cat=3 if cat==0 & inlist(UCC,"300111","300112","300211","300212","300216","300217")
replace cat=3 if cat==0 & inlist(UCC,"300221","300222","300311","300312","300321","300322")
replace cat=3 if cat==0 & inlist(UCC,"300331","300332","300411","300412")
replace cat=3 if cat==0 & inlist(UCC,"310110","310120","310130","310140","310210","310220")
replace cat=3 if cat==0 & inlist(UCC,"310230","310231","310232","310240","310243","310311")
replace cat=3 if cat==0 & inlist(UCC,"310312","310313","310314","310316","310320","310330")
replace cat=3 if cat==0 & inlist(UCC,"310333","310334","310340","310341","310342","310350")
replace cat=3 if cat==0 & UCC=="310400"
replace cat=3 if cat==0 & inlist(UCC,"690111","690112","690113","690115","690117","690118")
replace cat=3 if cat==0 & inlist(UCC,"690119","690120","690210","690220","690230")
replace cat=3 if cat==0 & inlist(UCC,"690241","690242","690244","690245")
replace cat=3 if cat==0 & inlist(UCC,"690310","690320","690330","690340","690350")
replace cat=3 if cat==0 & inlist(UCC,"600110","600121","600122","600127","600128")
replace cat=3 if cat==0 & inlist(UCC,"600131","600132","600137","600138","600141","600142")
replace cat=3 if cat==0 & inlist(UCC,"600143","600144","600210","600310","600410","600420")
replace cat=3 if cat==0 & inlist(UCC,"600430","600900","600901","600902")
replace cat=3 if cat==0 & inlist(UCC,"610110","610120","610130","610140","610210","610230")
replace cat=3 if cat==0 & UCC=="610320"
replace cat=3 if cat==0 & inlist(UCC,"320410","320420","320511","320512","320521","320522")
replace cat=3 if cat==0 & inlist(UCC,"320902","640420")
replace cat=3 if cat==0 & inlist(UCC,"220511","220512","220513","220611","220612")
replace cat=3 if cat==0 & inlist(UCC,"220613","220614","220615","220616")
replace cat=3 if cat==0 & inlist(UCC,"430110","430120","430130")
replace cat=3 if cat==0 & inlist(UCC,"870401","870402","870501","870502")
replace cat=3 if cat==0 & inlist(UCC,"870601","870605","870701","870702","870801")


gen cons_nondurable  = COST * (cat==1)
gen cons_services  = COST * (cat==2)
gen cons_durable = COST * (cat==3)


quietly collapse (sum) cons_nondurable cons_services cons_durable, ///
                 by(NEWID cal_quarter)

save "$out/mtbi_collapsed.dta", replace


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   MERGE 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
use"$out/mtbi_collapsed.dta"
merge m:1 NEWID using "$out/fmli_final.dta"

sort NEWID cal_quarter

foreach var in AGE_REF CUTENURE FINLWT21  ///
               INC_RANK  FSALARYX FSALARYM           ///
               LIQUIDX STOCKX FINCBTXM CKBKACTX SAVACCTX {
    
    by NEWID: replace `var' = `var'[_n-1] if missing(`var')
    
    by NEWID: replace `var' = `var'[_n+1] if missing(`var')
}

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
  Household Characteristics 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
gen cons_total      = cons_nondurable  + cons_services + cons_durable

* ── Mortgage holder ─────────────────────────────────────────────────────────
gen byte mortgage_holder = .
replace mortgage_holder = 1 if CUTENURE == 1
replace mortgage_holder = 0 if CUTENURE == 2


* ── Income quintile ─────────────────────────────────────────────────────────
gen byte income_quintile = .
gen yr4 = year(dofq(cal_quarter))

quietly xtile inc_q_rank = INC_RANK if yr4 != 2004 & yr4 != 2005, nquantiles(5)
quietly replace income_quintile = inc_q_rank if yr4 != 2004 & yr4 != 2005
quietly drop inc_q_rank

foreach y of numlist 2004 2005 {
    quietly xtile inc_q_`y' = FINCBTXM if yr4 == `y', nquantiles(5)
    quietly replace income_quintile = inc_q_`y' if yr4 == `y'
    quietly drop inc_q_`y'
}

quietly drop yr4

label define qlab 1 "Q1" 2 "Q2" 3 "Q3" 4 "Q4" 5 "Q5"
label values income_quintile qlab

* ── ④ Stock holder ────────────────────────────────────────────────────────────
gen byte stock_holder = .
replace  stock_holder = (STOCKX  > 0 & STOCKX  != .) if STOCKX  != .
replace  stock_holder = (SECESTX > 0 & SECESTX != .) ///
         if stock_holder == . & SECESTX != .

save "$out/cex_panel_final.dta", replace
