/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Baseline
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all

import excel "/Users/sunying/Desktop/Masterarbeit/thesis/data/macro.xlsx",firstrow case(lower)

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot = rgdp/emp 
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100

foreach var in rgdp rcons xtot tothours pgdp rstockp rhousep rcons_nondurable rcons_services rcons_durable{
  
  gen l`var' = ln(`var')
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}

gen tfp = dtfp_util

gen h = t - 1

global shock tfp

local p = 4 


forvalues i = 0/20 {

foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}
* ── Normalise to 1-SD shock ─────────────────────────────────────────

quietly summarize tfp
scalar sd_tfp = r(sd)

foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable {

    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    * Recompute bands from scaled b and se
    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}


* ── Figure 1 ─────────────────────────────────────────────
local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))

* Panel 1 — Real GDP 
twoway ///
    (rarea up90lrgdp lo90lrgdp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrgdp h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Real GDP", size(medsmall) color(black))                   ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))                ///
    saving(agg_lrgdp.gph, replace)


* Panel 2 — Stock Prices
twoway ///
    (rarea up90lrstockp lo90lrstockp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrstockp h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Stock Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrstockp.gph, replace)

* Panel 3 — House Prices
twoway ///
    (rarea up90lrhousep lo90lrhousep h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrhousep h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("House Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrhousep.gph, replace)

* Panel 4 — Consumption
twoway ///
    (rarea up90lrcons lo90lrcons h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Consumption", size(medsmall) color(black))                ///
    `gopts'                                                            ///
    saving(agg_lrcons.gph, replace)

graph combine                                                          ///
    agg_lrgdp.gph         agg_lrstockp.gph    agg_lrhousep.gph      agg_lrcons.gph                          ///
    , cols(2)                                                          ///
	name(irf_aggregate, replace)                                       ///
    graphregion(color(white)) iscale(0.85)





* ── Figure 7 ─────────────────────────────────────────────
local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
	ytitle("")  ///
	xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))


twoway ///
    (rarea up90lrcons_nondurable lo90lrcons_nondurable h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons_nondurable h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Nondurable", size(medsmall) color(black))                ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("Aggregate", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))                ///                                                           ///
    saving(agg_lrcons_nondurable.gph, replace)

twoway ///
    (rarea up90lrcons_services lo90lrcons_services h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons_services h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Services", size(medsmall) color(black))                ///
    `gopts'                                                            ///
    saving(agg_lrcons_services.gph, replace)
	
twoway ///
    (rarea up90lrcons_durable lo90lrcons_durable h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons_durable h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Durable", size(medsmall) color(black))                ///
    `gopts'                                                            ///
    saving(agg_lrcons_durable.gph, replace)

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Lag Selection
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all

import excel "/Users/sunying/Desktop/Masterarbeit/thesis/data/macro.xlsx",firstrow case(lower)

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot = rgdp/emp 
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100

foreach var in rgdp rcons xtot tothours pgdp rstockp rhousep rcons_nondurable rcons_services rcons_durable{
  
  gen l`var' = ln(`var')
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}

gen tfp = dtfp_util

gen h = t - 1

global shock tfp

local p = 6 


forvalues i = 0/20 {

foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}
* ── Normalise to 1-SD shock ─────────────────────────────────────────

quietly summarize tfp
scalar sd_tfp = r(sd)

foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable {

    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    * Recompute bands from scaled b and se
    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}


* ── Figure 1 ─────────────────────────────────────────────
local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))

* Panel 1 — Real GDP 
twoway ///
    (rarea up90lrgdp lo90lrgdp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrgdp h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Real GDP", size(medsmall) color(black))                   ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))                ///
    saving(agg_lrgdp_lag.gph, replace)


* Panel 2 — Stock Prices
twoway ///
    (rarea up90lrstockp lo90lrstockp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrstockp h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Stock Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrstockp_lag.gph, replace)

* Panel 3 — House Prices
twoway ///
    (rarea up90lrhousep lo90lrhousep h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrhousep h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("House Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrhousep_lag.gph, replace)

* Panel 4 — Consumption
twoway ///
    (rarea up90lrcons lo90lrcons h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Consumption", size(medsmall) color(black))                ///
    `gopts'                                                            ///
    saving(agg_lrcons_lag.gph, replace)



/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Cholesky 
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all

import excel "/Users/sunying/Desktop/Masterarbeit/thesis/data/macro.xlsx",firstrow case(lower)

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t  = _n
gen t2 = t^2

gen xtot    = rgdp / emp
gen rstockp = stockp_sh / pgdp * 100
gen rhousep = housep / pgdp * 100


foreach var in rgdp xtot tothours pgdp rstockp rhousep rcons {
    gen l`var' = ln(`var')
}

gen tfp = dtfp_util

local p = 4
local horizon = 20

var tfp lrgdp lrstockp lrhousep lxtot lrcons, ///
    lags(1/`p') exog(t t2)

irf create chol_agg, step(`horizon') set(irf_agg_chol) replace

quietly summarize tfp
scalar sd_tfp = r(sd)
global sd_tfp

use irf_agg_chol.irf, clear

keep if impulse == "tfp"
keep if inlist(response, "lrgdp", "lrstockp", "lrhousep", "lrcons")

gen upper = oirf + 1.68 * stdoirf
gen lower = oirf - 1.68 * stdoirf

foreach response in lrgdp lrstockp lrhousep lrcons {
    quietly replace oirf  = oirf  * 100 * sd_tfp if response == "`response'"
    quietly replace upper = upper * 100 * sd_tfp if response == "`response'"
    quietly replace lower = lower * 100 * sd_tfp if response == "`response'"
}

rename step h

save "irf_cholesky_data.dta", replace

local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters)", size(small) margin(top))          ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))

local title_lrgdp    "Real GDP"
local title_lrstockp "Stock prices"
local title_lrhousep "House prices"
local title_lrcons   "Consumption"

foreach resp in lrgdp lrstockp lrhousep lrcons {
    twoway ///
        (rarea upper lower h if response == "`resp'" & h<=20,        ///
            fcolor("27 58 92%40") lwidth(none))                      ///
        (line oirf h if response == "`resp'" & h<=20,                ///
            lcolor("27 58 92") lwidth(medthick) lpattern(solid))     ///
        , title("`title_`resp''", size(medsmall) color(black))       ///
        `gopts'                                                       ///
        saving(chol_`resp'.gph, replace)
}


/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
Residual
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/
clear all

import excel "/Users/sunying/Desktop/Masterarbeit/thesis/data/macro.xlsx",firstrow case(lower)

gen qdate = q(1989q4) + _n-1
tsset qdate, q

gen t = _n
gen t2 = t^2

gen xtot = rgdp/emp 
gen rstockp = stockp_sh/pgdp * 100
gen rhousep = housep/pgdp * 100

foreach var in rgdp rcons xtot tothours pgdp rstockp rhousep rcons_nondurable rcons_services rcons_durable{
  
  gen l`var' = ln(`var')
  quietly gen bl`var' = .
  quietly gen up90l`var' = .
  quietly gen lo90l`var' = .
  
}

gen tfp = dtfp_util

gen h = t - 1

newey tfp L(1/4).tfp L(1/4).lrgdp L(1/4).lrstockp L(1/4).lrhousep L(1/4).lxtot t t2,lag(4)
predict tfp_purged, resid

global shock tfp_purged

local p = 4 

forvalues i = 0/20 {


foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable{

newey F`i'.`var' L(0/`p').$shock L(1/`p').lrgdp L(1/`p').lrstockp L(1/`p').lrhousep L(1/`p').lxtot L(1/`p').`var' t t2, lag(`=`i' + 1')

  gen b`var'h`i' = _b[$shock]
  
  gen se`var'h`i' = _se[$shock]

  quietly replace b`var' = b`var'h`i' if h==`i' 
 
  quietly replace up90`var' = b`var'h`i' + 1.68*se`var'h`i' if h==`i'
  quietly replace lo90`var' = b`var'h`i' - 1.68*se`var'h`i' if h==`i'

  
}

}

quietly summarize tfp_purged
scalar sd_tfp = r(sd)

foreach var in lrgdp lrstockp lrhousep lrcons lrcons_nondurable lrcons_services lrcons_durable {

    forvalues i = 0/20 {
        quietly replace b`var'h`i'  = b`var'h`i'  * 100 * sd_tfp if h == `i'
        quietly replace se`var'h`i' = se`var'h`i' * 100 * sd_tfp if h == `i'
    }

    * Recompute bands from scaled b and se
    quietly replace up90`var' = .
    quietly replace lo90`var' = .
    forvalues i = 0/20 {
        quietly replace up90`var' = b`var'h`i' + 1.68 * se`var'h`i' if h == `i'
        quietly replace lo90`var' = b`var'h`i' - 1.68 * se`var'h`i' if h == `i'
    }
    quietly replace b`var' = b`var' * 100 * sd_tfp
}

local gopts ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Horizon h (Quarters) ", size(small) margin(top))           ///
    ytitle("% Dev. from Steady State", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))

* Panel 1 — Real GDP 
twoway ///
    (rarea up90lrgdp lo90lrgdp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrgdp h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Real GDP", size(medsmall) color(black))                   ///
    xlabel(0(5)20, labsize(small) grid glcolor(gs14) glpattern(dash)) ///
    ylabel(, labsize(small) grid glcolor(gs14) glpattern(dash))       ///
    xtitle("Quarters after shock", size(small) margin(top))           ///
    ytitle("% deviation from steady state", size(small) margin(right)) ///
    yline(0, lcolor(black) lwidth(thin))                              ///
    legend(off)                                                        ///
    graphregion(color(white)) plotregion(color(white))                ///
    saving(agg_lrgdp_residual.gph, replace)


* Panel 2 — Stock Prices
twoway ///
    (rarea up90lrstockp lo90lrstockp h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrstockp h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Stock Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrstockp_residual.gph, replace)

* Panel 3 — House Prices
twoway ///
    (rarea up90lrhousep lo90lrhousep h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrhousep h if h<=20,                                        ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("House Prices", size(medsmall) color(black))               ///
    `gopts'                                                            ///
    saving(agg_lrhousep_residual.gph, replace)

* Panel 4 — Consumption
twoway ///
    (rarea up90lrcons lo90lrcons h if h<=20, ///
        fcolor("27 58 92%40") lwidth(none))                        ///
    (line blrcons h if h<=20,                                          ///
        lcolor("27 58 92") lwidth(medthick) lpattern(solid))         ///
    , title("Consumption", size(medsmall) color(black))                ///
    `gopts'                                                            ///
    saving(agg_lrcons_residual.gph, replace)

